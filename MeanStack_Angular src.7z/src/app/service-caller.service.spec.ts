import { TestBed, inject } from '@angular/core/testing';

import { ServiceCallerService } from './service-caller.service';

describe('ServiceCallerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ServiceCallerService]
    });
  });

  it('should be created', inject([ServiceCallerService], (service: ServiceCallerService) => {
    expect(service).toBeTruthy();
  }));
});
