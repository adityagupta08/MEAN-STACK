import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {Observable} from 'rxjs'
import {emp} from  './emp'

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http: HttpClient) { }

  getMethod(){
    return this.http.get('http://localhost:3200/rest/api/load');
  }

  postData(uname:string,password:string){

    console.log("Uname :"+uname);
    console.log("Pass; "+password);

   return this.http.post('http://localhost:3200/rest/api/post',{
      "user":uname,
      "pass":password
    })

  }



  getPostData()
{
   return this.http.get<emp[]>('http://localhost:3200/rest/api/poster');
  }


}