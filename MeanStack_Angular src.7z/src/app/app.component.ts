import { Component } from '@angular/core';
import {ServiceService} from './service.service'
import { HttpClient } from '@angular/common/http';
import {emp} from  './emp'
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  xya:any;
  user:string;
  pass:string

  constructor(private _serv:ServiceService){}
  title = 'app';
res:any;
ngOnInit(){
  // this._serv.getMethod().subscribe(
  //   (data:x)=>{
  //     this.data=data.msg;
  //     console.log(this.data)
  //   },
  //     (err: HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  // );
}
InvokeGet()
{
  this._serv.getMethod().subscribe(
    (data:x)=>{
      this.xya=data.msg;
      // console.log(this.data)
    },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
  );
}

InvokePost() {
  console.log(this.user, this.pass);
  this._serv.postData(this.user, this.pass).subscribe((data:emp) => {
    console.log("<<<<<<<<>>>>>>>>>"+data)

this.res=data.user;
console.log("123 "+this.res);
  })
}

getPost(){

  console.log("Getting Data of Post")
  this._serv.getPostData().subscribe((data)=>{

    for(let e of data)
    {
console.log("<<<<<<<<<>.........>"+e.user+"  "+e.pass)

    }
    
  })

}


}



interface x{
  msg:any;
}