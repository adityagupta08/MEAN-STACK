export interface emp
{
    _id:string,
    user:string,
    pass:string
}